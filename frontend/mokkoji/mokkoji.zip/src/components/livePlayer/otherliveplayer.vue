<template>
  <div class="otherlive">
    <div></div>
  </div>
</template>

<script setup></script>

<style scoped>
.otherlive {
  display: flex;
  width: 90%;
  height: 52px;
  background-color: #015dba;
  margin: 3% 0%;
  margin-left: 18px;
  margin-right: 18px;
  border-radius: 10px;
  font-size: 39px;
}
</style>
